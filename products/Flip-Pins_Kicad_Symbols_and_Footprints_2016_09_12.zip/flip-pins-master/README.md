# flip-pins

KiCAD symbols, footprints and 3D models for FLIP-PINs-xx from OSHchip

![flip-pins schematic](https://github.com/wyolum/flip-pins/blob/master/images/flip-pins-sch.png)

![flip-pins footprint](https://github.com/wyolum/flip-pins/blob/master/images/flip-pins-fp.png)

![flip-pins 3D](https://github.com/wyolum/flip-pins/blob/master/images/flip-pins-3d.png)

![flip-pins 3D](https://github.com/wyolum/flip-pins/blob/master/images/flip-pins-3d-08.png)


License
-------
[CERN Open Hardware Licence v1.2 ]

[CERN Open Hardware Licence v1.2 ]:http://www.ohwr.org/attachments/2388/cern_ohl_v_1_2.txt
